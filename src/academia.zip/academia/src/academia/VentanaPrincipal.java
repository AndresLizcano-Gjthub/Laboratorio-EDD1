package academia;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.IOException;
import java.time.LocalDate;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * Ventana principal: un JFrame con 4 pestañas (JTabbedPane), cada una
 * un JPanel con un formulario arriba, botones en medio y un área de
 * texto abajo para mostrar resultados y listados.
 *
 * Esta clase solo arma la interfaz y responde a los botones.
 * Toda la lectura y escritura de archivos está en Personas.java y Sesiones.java.
 */
public class VentanaPrincipal extends JFrame {

    // Paleta de colores de toda la ventana
    private static final Color AZUL = new Color(33, 64, 105);
    private static final Color AZUL_CLARO = new Color(219, 231, 245);
    private static final Color CREMA = new Color(247, 247, 243);
    private static final Color VERDE_BOTON = new Color(60, 130, 90);
    private static final Font FUENTE_TITULO = new Font("SansSerif", Font.BOLD, 14);
    private static final Font FUENTE_TEXTO = new Font("SansSerif", Font.PLAIN, 13);

    public VentanaPrincipal() {
        setTitle("Academia de Artes Barranquilla");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 620);
        setLocationRelativeTo(null);

        add(crearEncabezado(), BorderLayout.NORTH);

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.setFont(FUENTE_TITULO);
        pestanas.addTab("Instructores", panelPersona("instructor",
                Academia.INSTRUCTORES_DAT, Academia.INSTRUCTORES_IDX, Academia.indiceInstructores, true));
        pestanas.addTab("Aprendices", panelPersona("aprendiz",
                Academia.APRENDICES_DAT, Academia.APRENDICES_IDX, Academia.indiceAprendices, false));
        pestanas.addTab("Sesiones", panelSesiones());
        pestanas.addTab("Reportes", panelReportes());

        add(pestanas, BorderLayout.CENTER);
    }

    // ==================================================================
    // ENCABEZADO
    // ==================================================================
    private JPanel crearEncabezado() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(AZUL);
        panel.setBorder(new EmptyBorder(14, 20, 14, 20));

        JLabel titulo = new JLabel("Academia de Artes Barranquilla");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);

        JLabel subtitulo = new JLabel("Gestión de instructores, aprendices y sesiones");
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitulo.setForeground(AZUL_CLARO);

        JPanel textos = new JPanel(new GridLayout(2, 1));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(subtitulo);

        panel.add(textos, BorderLayout.WEST);
        return panel;
    }

    // ==================================================================
    // APOYO VISUAL: caja con título alrededor de un panel
    // ==================================================================
    private JPanel caja(String titulo, JPanel contenido) {
        JPanel caja = new JPanel(new BorderLayout());
        caja.setBackground(CREMA);
        TitledBorder borde = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(AZUL, 1), titulo);
        borde.setTitleFont(FUENTE_TITULO);
        borde.setTitleColor(AZUL);
        caja.setBorder(borde);
        caja.add(contenido, BorderLayout.CENTER);
        return caja;
    }

    private JButton boton(String texto) {
        JButton b = new JButton(texto);
        b.setFont(FUENTE_TEXTO);
        b.setBackground(AZUL);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(6, 14, 6, 14));
        return b;
    }

    private JTextArea areaResultado() {
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setBackground(Color.WHITE);
        area.setMargin(new java.awt.Insets(8, 8, 8, 8));
        return area;
    }

    private JScrollPane conTitulo(String titulo, JTextArea area) {
        JScrollPane scroll = new JScrollPane(area);
        TitledBorder borde = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)), titulo);
        borde.setTitleFont(FUENTE_TITULO);
        scroll.setBorder(borde);
        return scroll;
    }

    // ==================================================================
    // PESTAÑA DE INSTRUCTORES / APRENDICES (mismo formulario para los dos)
    // ==================================================================
    private JPanel panelPersona(String titulo, String dat, String idx,
            java.util.HashMap<String, Long> indice, boolean especialidadUnica) {

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(CREMA);
        panel.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField txtCedula = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtEspecialidad = new JTextField(); // texto libre para aprendices
        JComboBox<String> cboEspecialidad = new JComboBox<String>(Archivos.ESPECIALIDADES); // lista para instructores
        JTextField txtTelefono = new JTextField();

        JPanel formulario = new JPanel(new GridLayout(4, 2, 8, 10));
        formulario.setBackground(CREMA);
        formulario.setBorder(new EmptyBorder(10, 10, 10, 10));
        formulario.add(etiqueta("Cédula:"));
        formulario.add(txtCedula);
        formulario.add(etiqueta("Nombre:"));
        formulario.add(txtNombre);
        if (especialidadUnica) {
            formulario.add(etiqueta("Especialidad:"));
            formulario.add(cboEspecialidad);
        } else {
            formulario.add(etiqueta("Especialidades (separadas por coma):"));
            formulario.add(txtEspecialidad);
        }
        formulario.add(etiqueta("Teléfono:"));
        formulario.add(txtTelefono);

        JPanel botones = new JPanel();
        botones.setBackground(CREMA);
        JButton btnAgregar = boton("Agregar");
        JButton btnConsultar = boton("Consultar");
        JButton btnModificar = boton("Modificar");
        JButton btnEliminar = boton("Eliminar");
        JButton btnListar = boton("Listar");
        botones.add(btnAgregar);
        botones.add(btnConsultar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnListar);

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.setBackground(CREMA);
        arriba.add(caja("Datos del " + titulo, formulario), BorderLayout.CENTER);
        arriba.add(botones, BorderLayout.SOUTH);

        JTextArea area = areaResultado();

        panel.add(arriba, BorderLayout.NORTH);
        panel.add(conTitulo("Resultado", area), BorderLayout.CENTER);

        btnAgregar.addActionListener(e -> {
            String especialidad = especialidadUnica
                    ? (String) cboEspecialidad.getSelectedItem() : txtEspecialidad.getText();
            try {
                String error = Personas.agregar(dat, idx, indice, txtCedula.getText(),
                        txtNombre.getText(), especialidad, txtTelefono.getText());
                area.setText(error == null ? "Registro guardado correctamente." : error);
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnConsultar.addActionListener(e -> {
            try {
                String[] p = Personas.buscar(dat, indice, txtCedula.getText().trim());
                if (p == null) {
                    area.setText("No existe un " + titulo + " con esa cédula.");
                } else {
                    txtNombre.setText(p[1]);
                    if (especialidadUnica) {
                        cboEspecialidad.setSelectedItem(p[2]);
                    } else {
                        txtEspecialidad.setText(p[2]);
                    }
                    txtTelefono.setText(p[3]);
                    area.setText("Cédula: " + p[0] + "\nNombre: " + p[1] + "\nEspecialidad(es): " + p[2]
                            + "\nTeléfono: " + p[3] + "\nSesiones del mes: " + p[4]);
                }
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnModificar.addActionListener(e -> {
            String especialidad = especialidadUnica
                    ? (String) cboEspecialidad.getSelectedItem() : txtEspecialidad.getText();
            try {
                String error = Personas.modificar(dat, indice, txtCedula.getText(),
                        txtNombre.getText(), especialidad, txtTelefono.getText());
                area.setText(error == null ? "Registro modificado." : error);
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnEliminar.addActionListener(e -> {
            int confirmar = JOptionPane.showConfirmDialog(this,
                    "¿Eliminar el registro con cédula " + txtCedula.getText() + "?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirmar != JOptionPane.YES_OPTION) {
                return;
            }
            try {
                String error = Personas.eliminar(dat, idx, indice, txtCedula.getText());
                area.setText(error == null ? "Registro eliminado." : error);
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnListar.addActionListener(e -> {
            try {
                area.setText(Personas.listarTexto(dat));
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        return panel;
    }

    // ==================================================================
    // PESTAÑA DE SESIONES
    // ==================================================================
    private JPanel panelSesiones() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(CREMA);
        panel.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField txtCedulaAprendiz = new JTextField();
        JComboBox<String> cboEspecialidad = new JComboBox<String>(Archivos.ESPECIALIDADES);
        JTextField txtCedulaInstructor = new JTextField();
        JTextField txtFecha = new JTextField(LocalDate.now().plusDays(1).toString());
        JTextField txtCodigo = new JTextField();

        JPanel formulario = new JPanel(new GridLayout(4, 2, 8, 10));
        formulario.setBackground(CREMA);
        formulario.setBorder(new EmptyBorder(10, 10, 10, 10));
        formulario.add(etiqueta("Cédula del aprendiz:"));
        formulario.add(txtCedulaAprendiz);
        formulario.add(etiqueta("Especialidad:"));
        formulario.add(cboEspecialidad);
        formulario.add(etiqueta("Cédula del instructor (ver disponibles primero):"));
        formulario.add(txtCedulaInstructor);
        formulario.add(etiqueta("Fecha (aaaa-mm-dd):"));
        formulario.add(txtFecha);

        JPanel botones = new JPanel();
        botones.setBackground(CREMA);
        JButton btnDisponibles = boton("Ver instructores disponibles");
        JButton btnAsignar = boton("Asignar sesión");
        JButton btnListar = boton("Listar todas");
        JButton btnPorAprendiz = boton("Consultar por aprendiz");
        botones.add(btnDisponibles);
        botones.add(btnAsignar);
        botones.add(btnListar);
        botones.add(btnPorAprendiz);

        JPanel cancelacion = new JPanel();
        cancelacion.setBackground(CREMA);
        cancelacion.add(etiqueta("Código a cancelar:"));
        cancelacion.add(txtCodigo);
        JButton btnCancelar = boton("Cancelar sesión");
        cancelacion.add(btnCancelar);

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.setBackground(CREMA);
        arriba.add(caja("Asignar sesión", formulario), BorderLayout.NORTH);
        arriba.add(botones, BorderLayout.CENTER);
        arriba.add(cancelacion, BorderLayout.SOUTH);

        JTextArea area = areaResultado();

        panel.add(arriba, BorderLayout.NORTH);
        panel.add(conTitulo("Resultado", area), BorderLayout.CENTER);

        btnDisponibles.addActionListener(e -> {
            try {
                String especialidad = (String) cboEspecialidad.getSelectedItem();
                String texto = Sesiones.instructoresDisponibles(especialidad);
                area.setText(texto.equals("") ? "No hay instructores disponibles." : texto);
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnAsignar.addActionListener(e -> {
            try {
                String especialidad = (String) cboEspecialidad.getSelectedItem();
                area.setText(Sesiones.asignar(txtCedulaAprendiz.getText(), especialidad,
                        txtCedulaInstructor.getText(), txtFecha.getText()));
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnListar.addActionListener(e -> {
            try {
                area.setText(Sesiones.listar(""));
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnPorAprendiz.addActionListener(e -> {
            try {
                area.setText(Sesiones.listar(txtCedulaAprendiz.getText()));
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnCancelar.addActionListener(e -> {
            int confirmar = JOptionPane.showConfirmDialog(this,
                    "¿Cancelar la sesión " + txtCodigo.getText() + "?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirmar != JOptionPane.YES_OPTION) {
                return;
            }
            try {
                area.setText(Sesiones.cancelar(txtCodigo.getText()));
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        return panel;
    }

    // ==================================================================
    // PESTAÑA DE REPORTES
    // ==================================================================
    private JPanel panelReportes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(CREMA);
        panel.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextArea area = areaResultado();

        JPanel botones = new JPanel();
        botones.setBackground(CREMA);
        JButton btnReporte = boton("Generar reporte");
        JButton btnReiniciar = boton("Reiniciar mes");
        botones.add(btnReporte);
        botones.add(btnReiniciar);

        panel.add(botones, BorderLayout.NORTH);
        panel.add(conTitulo("Reporte", area), BorderLayout.CENTER);

        btnReporte.addActionListener(e -> {
            try {
                area.setText(Sesiones.reporte());
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        btnReiniciar.addActionListener(e -> {
            int confirmar = JOptionPane.showConfirmDialog(this,
                    "Esto pondrá en 0 las sesiones de instructores y aprendices. ¿Continuar?",
                    "Reinicio de mes", JOptionPane.YES_NO_OPTION);
            if (confirmar != JOptionPane.YES_OPTION) {
                return;
            }
            try {
                int ins = Personas.reiniciar(Academia.INSTRUCTORES_DAT);
                int apr = Personas.reiniciar(Academia.APRENDICES_DAT);
                area.setText("Mes reiniciado: " + ins + " instructores y " + apr + " aprendices en 0 sesiones.");
            } catch (IOException ex) {
                mostrarErrorArchivo(ex);
            }
        });

        return panel;
    }

    // ==================================================================
    // APOYO
    // ==================================================================
    private JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(FUENTE_TEXTO);
        l.setHorizontalAlignment(SwingConstants.LEFT);
        return l;
    }

    private void mostrarErrorArchivo(IOException ex) {
        JOptionPane.showMessageDialog(this, "Error con los archivos: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}