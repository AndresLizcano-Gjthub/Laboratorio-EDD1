package academia;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;

// CRUD de instructores y aprendices. Mismos campos, mismos métodos,
// solo cambia el nombre del archivo y su índice.
// Registro: [0]=cédula [1]=nombre [2]=especialidad(es) [3]=teléfono [4]=sesiones [5]=activo
//
// Estos métodos NO muestran ventanas: reciben los datos ya escritos por el
// usuario y devuelven null si todo salió bien, o un mensaje de error si no.
// La interfaz gráfica (VentanaPrincipal) es la que arma esos mensajes en pantalla.
public class Personas {

    public static final int LARGO_CEDULA = 10;
    public static final int LARGO_NOMBRE = 25;
    public static final int LARGO_ESPECIALIDAD = 25;
    public static final int LARGO_TELEFONO = 10;
    public static final int TAMANO =
            (LARGO_CEDULA + LARGO_NOMBRE + LARGO_ESPECIALIDAD + LARGO_TELEFONO) * 2 + 4 + 1;

    public static void escribir(RandomAccessFile archivo, String[] p) throws IOException {
        Archivos.escribirCadena(archivo, p[0], LARGO_CEDULA);
        Archivos.escribirCadena(archivo, p[1], LARGO_NOMBRE);
        Archivos.escribirCadena(archivo, p[2], LARGO_ESPECIALIDAD);
        Archivos.escribirCadena(archivo, p[3], LARGO_TELEFONO);
        archivo.writeInt(Integer.parseInt(p[4]));
        archivo.writeBoolean(p[5].equals("true"));
    }

    public static String[] leer(RandomAccessFile archivo) throws IOException {
        String[] p = new String[6];
        p[0] = Archivos.leerCadena(archivo, LARGO_CEDULA);
        p[1] = Archivos.leerCadena(archivo, LARGO_NOMBRE);
        p[2] = Archivos.leerCadena(archivo, LARGO_ESPECIALIDAD);
        p[3] = Archivos.leerCadena(archivo, LARGO_TELEFONO);
        p[4] = "" + archivo.readInt();
        p[5] = "" + archivo.readBoolean();
        return p;
    }

    public static String[] buscar(String dat, HashMap<String, Long> indice, String cedula)
            throws IOException {

        if (!indice.containsKey(cedula)) {
            return null;
        }
        RandomAccessFile archivo = new RandomAccessFile(dat, "r");
        archivo.seek(indice.get(cedula));
        String[] p = leer(archivo);
        archivo.close();
        return p;
    }

    public static void reescribir(String dat, HashMap<String, Long> indice, String[] p)
            throws IOException {

        RandomAccessFile archivo = new RandomAccessFile(dat, "rw");
        archivo.seek(indice.get(p[0]));
        escribir(archivo, p);
        archivo.close();
    }

    public static void cambiarSesiones(String dat, HashMap<String, Long> indice,
            String cedula, int cantidad) throws IOException {

        String[] p = buscar(dat, indice, cedula);
        if (p == null) {
            return;
        }
        int nuevas = Integer.parseInt(p[4]) + cantidad;
        if (nuevas < 0) {
            nuevas = 0;
        }
        p[4] = "" + nuevas;
        reescribir(dat, indice, p);
    }

    /** CREATE. Devuelve null si quedó bien, o el mensaje de error. */
    public static String agregar(String dat, String idx, HashMap<String, Long> indice,
            String cedula, String nombre, String especialidad, String telefono) throws IOException {

        cedula = cedula == null ? "" : cedula.trim();
        if (!Archivos.esNumero(cedula) || cedula.length() > LARGO_CEDULA) {
            return "La cédula debe tener solo números (máximo 10 dígitos).";
        }
        if (indice.containsKey(cedula)) {
            return "Ya existe un registro con la cédula " + cedula + ".";
        }
        if (nombre == null || nombre.trim().equals("")) {
            return "El nombre no puede quedar vacío.";
        }
        if (especialidad == null || especialidad.trim().equals("")) {
            return "Debe indicar la especialidad.";
        }
        telefono = telefono == null ? "" : telefono.trim();
        if (!Archivos.esNumero(telefono)) {
            return "El teléfono debe tener solo números.";
        }

        String[] p = {cedula, nombre.trim(), especialidad.trim().toLowerCase(), telefono, "0", "true"};

        RandomAccessFile archivo = new RandomAccessFile(dat, "rw");
        long posicion = archivo.length();
        archivo.seek(posicion);
        escribir(archivo, p);
        archivo.close();

        indice.put(cedula, posicion);
        Archivos.guardarIndice(idx, indice, LARGO_CEDULA);
        return null;
    }

    /** UPDATE. Devuelve null si quedó bien, o el mensaje de error. */
    public static String modificar(String dat, HashMap<String, Long> indice, String cedula,
            String nombre, String especialidad, String telefono) throws IOException {

        cedula = cedula == null ? "" : cedula.trim();
        String[] p = buscar(dat, indice, cedula);
        if (p == null) {
            return "No existe un registro con esa cédula.";
        }
        if (nombre == null || nombre.trim().equals("")) {
            return "El nombre no puede quedar vacío.";
        }
        if (especialidad == null || especialidad.trim().equals("")) {
            return "Debe indicar la especialidad.";
        }
        telefono = telefono == null ? "" : telefono.trim();
        if (!Archivos.esNumero(telefono)) {
            return "El teléfono debe tener solo números.";
        }

        p[1] = nombre.trim();
        p[2] = especialidad.trim().toLowerCase();
        p[3] = telefono;
        reescribir(dat, indice, p);
        return null;
    }

    /** DELETE lógico: activo = false y se saca del índice. */
    public static String eliminar(String dat, String idx, HashMap<String, Long> indice, String cedula)
            throws IOException {

        cedula = cedula == null ? "" : cedula.trim();
        String[] p = buscar(dat, indice, cedula);
        if (p == null) {
            return "No se puede eliminar: el registro no existe.";
        }
        p[5] = "false";
        reescribir(dat, indice, p);
        indice.remove(cedula);
        Archivos.guardarIndice(idx, indice, LARGO_CEDULA);
        return null;
    }

    /** Recorrido secuencial de todo el archivo. */
    public static String listarTexto(String dat) throws IOException {
        File datos = new File(dat);
        if (!datos.exists() || datos.length() == 0) {
            return "Todavía no hay registros.";
        }

        String texto = "CEDULA      NOMBRE                   ESPECIALIDAD(ES)          TELEFONO    SESIONES\n";
        RandomAccessFile archivo = new RandomAccessFile(dat, "r");
        while (archivo.getFilePointer() < archivo.length()) {
            String[] p = leer(archivo);
            if (p[5].equals("true")) {
                texto = texto + Archivos.rellenar(p[0], 12) + Archivos.rellenar(p[1], 25)
                        + Archivos.rellenar(p[2], 26) + Archivos.rellenar(p[3], 12) + p[4] + "\n";
            }
        }
        archivo.close();
        return texto;
    }

    /** Reinicio de mes: deja el contador de sesiones en 0. Devuelve cuántos registros cambió. */
    public static int reiniciar(String dat) throws IOException {
        File datos = new File(dat);
        if (!datos.exists() || datos.length() == 0) {
            return 0;
        }

        int cuenta = 0;
        RandomAccessFile archivo = new RandomAccessFile(dat, "rw");
        long posicion = 0;
        while (posicion < archivo.length()) {
            archivo.seek(posicion);
            String[] p = leer(archivo);
            if (p[5].equals("true")) {
                p[4] = "0";
                archivo.seek(posicion);
                escribir(archivo, p);
                cuenta = cuenta + 1;
            }
            posicion = posicion + TAMANO;
        }
        archivo.close();
        return cuenta;
    }
}