package academia;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.util.HashMap;

// Herramientas comunes: cadenas de tamaño fijo, índice y validaciones
public class Archivos {

    public static final String[] ESPECIALIDADES = {"musica", "pintura", "escritura", "baile", "teatro"};

    // Todo registro debe ocupar los mismos bytes para poder usar seek().
    public static String rellenar(String texto, int largo) {
        if (texto == null) {
            texto = "";
        }
        if (texto.length() > largo) {
            return texto.substring(0, largo);
        }
        while (texto.length() < largo) {
            texto = texto + " ";
        }
        return texto;
    }

    // writeChars() usa 2 bytes por carácter (UTF-16)
    public static void escribirCadena(RandomAccessFile archivo, String texto, int largo) throws IOException {
        archivo.writeChars(rellenar(texto, largo));
    }

    public static String leerCadena(RandomAccessFile archivo, int largo) throws IOException {
        String texto = "";
        for (int i = 0; i < largo; i++) {
            texto = texto + archivo.readChar();
        }
        return texto.trim();
    }

    // El .idx guarda (llave -> posición). Se carga a un HashMap para buscar directo.
    public static void cargarIndice(String archivoDat, String archivoIdx,
            HashMap<String, Long> indice, int largoLlave, int tamRegistro) throws IOException {

        indice.clear();
        File idx = new File(archivoIdx);

        if (idx.exists() && idx.length() > 0) {
            RandomAccessFile archivo = new RandomAccessFile(archivoIdx, "r");
            while (archivo.getFilePointer() < archivo.length()) {
                String llave = leerCadena(archivo, largoLlave);
                indice.put(llave, archivo.readLong());
            }
            archivo.close();
        } else {
            // sin .idx: se reconstruye recorriendo el .dat SECUENCIALMENTE
            File datos = new File(archivoDat);
            if (datos.exists() && datos.length() > 0) {
                RandomAccessFile archivo = new RandomAccessFile(archivoDat, "r");
                long posicion = 0;
                while (posicion < archivo.length()) {
                    archivo.seek(posicion);
                    String llave = leerCadena(archivo, largoLlave);
                    archivo.seek(posicion + tamRegistro - 1); // último byte = "activo"
                    if (archivo.readBoolean()) {
                        indice.put(llave, posicion);
                    }
                    posicion = posicion + tamRegistro;
                }
                archivo.close();
            }
            guardarIndice(archivoIdx, indice, largoLlave);
        }
    }

    public static void guardarIndice(String archivoIdx, HashMap<String, Long> indice,
            int largoLlave) throws IOException {

        RandomAccessFile archivo = new RandomAccessFile(archivoIdx, "rw");
        archivo.setLength(0);
        for (String llave : indice.keySet()) {
            escribirCadena(archivo, llave, largoLlave);
            archivo.writeLong(indice.get(llave));
        }
        archivo.close();
    }

    public static boolean esNumero(String texto) {
        if (texto == null || texto.trim().equals("")) {
            return false;
        }
        texto = texto.trim();
        for (int i = 0; i < texto.length(); i++) {
            if (!Character.isDigit(texto.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean fechaValida(String fecha) {
        if (fecha == null || fecha.length() != 10) {
            return false;
        }
        if (fecha.charAt(4) != '-' || fecha.charAt(7) != '-') {
            return false;
        }
        if (!esNumero(fecha.substring(0, 4)) || !esNumero(fecha.substring(5, 7))
                || !esNumero(fecha.substring(8, 10))) {
            return false;
        }
        int mes = Integer.parseInt(fecha.substring(5, 7));
        int dia = Integer.parseInt(fecha.substring(8, 10));
        return mes >= 1 && mes <= 12 && dia >= 1 && dia <= 31;
    }

    public static String hoy() {
        return LocalDate.now().toString();
    }
}