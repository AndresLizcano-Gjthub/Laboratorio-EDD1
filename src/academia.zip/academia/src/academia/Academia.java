package academia;

import java.io.IOException;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

// LABORATORIO 1 - Academia de Artes Barranquilla
// Archivos: instructores.dat/.idx, aprendices.dat/.idx, sesiones.dat/.idx
public class Academia {

    public static final String INSTRUCTORES_DAT = "instructores.dat";
    public static final String INSTRUCTORES_IDX = "instructores.idx";
    public static final String APRENDICES_DAT = "aprendices.dat";
    public static final String APRENDICES_IDX = "aprendices.idx";
    public static final String SESIONES_DAT = "sesiones.dat";
    public static final String SESIONES_IDX = "sesiones.idx";

    public static HashMap<String, Long> indiceInstructores = new HashMap<String, Long>();
    public static HashMap<String, Long> indiceAprendices = new HashMap<String, Long>();

    public static void main(String[] args) {
        try {
            // Al iniciar se cargan los tres índices a memoria (HashMap)
            Archivos.cargarIndice(INSTRUCTORES_DAT, INSTRUCTORES_IDX, indiceInstructores,
                    Personas.LARGO_CEDULA, Personas.TAMANO);
            Archivos.cargarIndice(APRENDICES_DAT, APRENDICES_IDX, indiceAprendices,
                    Personas.LARGO_CEDULA, Personas.TAMANO);
            Archivos.cargarIndice(SESIONES_DAT, SESIONES_IDX, Sesiones.indice,
                    Sesiones.LARGO_CODIGO, Sesiones.TAMANO);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error con los archivos: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}