package academia;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;

// Archivo de sesiones: asignar, consultar, cancelar y reporte.
// Registro: [0]=código [1]=céd.aprendiz [2]=nom.aprendiz [3]=especialidad
//           [4]=céd.instructor [5]=nom.instructor [6]=fecha [7]=activa
//
// Igual que en Personas: estos métodos no muestran ventanas, solo devuelven
// texto. Los mensajes de resultado empiezan con "OK:" o "ERROR:".
public class Sesiones {

    public static final int LARGO_CODIGO = 5;
    public static final int TAMANO = (LARGO_CODIGO + aaaaa.LARGO_CEDULA + aaaaa.LARGO_NOMBRE
            + aaaaa.LARGO_ESPECIALIDAD + aaaaa.LARGO_CEDULA + aaaaa.LARGO_NOMBRE + 10) * 2 + 1;

    public static final int MAX_INSTRUCTOR = 15; // sesiones al mes por instructor
    public static final int MAX_APRENDIZ = 4;    // sesiones al mes por especialidad

    public static HashMap<String, Long> indice = new HashMap<String, Long>();

    public static void escribir(RandomAccessFile archivo, String[] s) throws IOException {
        Archivos.escribirCadena(archivo, s[0], LARGO_CODIGO);
        Archivos.escribirCadena(archivo, s[1], aaaaa.LARGO_CEDULA);
        Archivos.escribirCadena(archivo, s[2], aaaaa.LARGO_NOMBRE);
        Archivos.escribirCadena(archivo, s[3], aaaaa.LARGO_ESPECIALIDAD);
        Archivos.escribirCadena(archivo, s[4], aaaaa.LARGO_CEDULA);
        Archivos.escribirCadena(archivo, s[5], aaaaa.LARGO_NOMBRE);
        Archivos.escribirCadena(archivo, s[6], 10);
        archivo.writeBoolean(s[7].equals("true"));
    }

    public static String[] leer(RandomAccessFile archivo) throws IOException {
        String[] s = new String[8];
        s[0] = Archivos.leerCadena(archivo, LARGO_CODIGO);
        s[1] = Archivos.leerCadena(archivo, aaaaa.LARGO_CEDULA);
        s[2] = Archivos.leerCadena(archivo, aaaaa.LARGO_NOMBRE);
        s[3] = Archivos.leerCadena(archivo, aaaaa.LARGO_ESPECIALIDAD);
        s[4] = Archivos.leerCadena(archivo, aaaaa.LARGO_CEDULA);
        s[5] = Archivos.leerCadena(archivo, aaaaa.LARGO_NOMBRE);
        s[6] = Archivos.leerCadena(archivo, 10);
        s[7] = "" + archivo.readBoolean();
        return s;
    }

    public static String[] buscar(String codigo) throws IOException {
        if (!indice.containsKey(codigo)) {
            return null;
        }
        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "r");
        archivo.seek(indice.get(codigo));
        String[] s = leer(archivo);
        archivo.close();
        return s;
    }

    /**
     * PROCESO DE ASIGNACIÓN: valida aprendiz, tope de 4 por especialidad,
     * instructor con cupo, fecha futura y que no esté repetida.
     * Devuelve un mensaje "OK: ..." con el código, o "ERROR: ..." con el motivo.
     */
    public static String asignar(String cedApr, String especialidad, String cedIns, String fecha)
            throws IOException {

        cedApr = cedApr == null ? "" : cedApr.trim();
        String[] aprendiz = aaaaa.buscar(Academia.APRENDICES_DAT, Academia.indiceAprendices, cedApr);
        if (aprendiz == null) {
            return "ERROR: El aprendiz no está registrado.";
        }
        if (especialidad == null || especialidad.trim().equals("")) {
            return "ERROR: Seleccione una especialidad.";
        }

        int tiene = contarDelAprendiz(cedApr, especialidad);
        if (tiene >= MAX_APRENDIZ) {
            return "ERROR: El aprendiz ya tiene " + tiene + " sesiones de " + especialidad
                    + " este mes (máximo " + MAX_APRENDIZ + ").";
        }

        cedIns = cedIns == null ? "" : cedIns.trim();
        String[] instructor = aaaaa.buscar(Academia.INSTRUCTORES_DAT, Academia.indiceInstructores, cedIns);
        if (instructor == null || !instructor[2].equalsIgnoreCase(especialidad)) {
            return "ERROR: Ese instructor no existe o no dicta " + especialidad + ".";
        }
        if (Integer.parseInt(instructor[4]) >= MAX_INSTRUCTOR) {
            return "ERROR: Ese instructor ya tiene " + MAX_INSTRUCTOR + " sesiones este mes.";
        }

        fecha = fecha == null ? "" : fecha.trim();
        if (!Archivos.fechaValida(fecha)) {
            return "ERROR: Fecha mal escrita. Use aaaa-mm-dd.";
        }
        // formato aaaa-mm-dd: se pueden comparar los textos directamente
        if (fecha.compareTo(Archivos.hoy()) < 0) {
            return "ERROR: No se pueden programar sesiones en fechas pasadas.";
        }
        if (hayRepetida(cedApr, cedIns, fecha)) {
            return "ERROR: Ya hay una sesión de ese aprendiz o instructor el " + fecha + ".";
        }

        File datos = new File(Academia.SESIONES_DAT);
        long total = datos.exists() ? datos.length() / TAMANO : 0;
        String codigo = "S" + String.format("%04d", total + 1);

        String[] s = {codigo, cedApr, aprendiz[1], especialidad, cedIns, instructor[1], fecha, "true"};

        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "rw");
        long posicion = archivo.length();
        archivo.seek(posicion);
        escribir(archivo, s);
        archivo.close();

        indice.put(codigo, posicion);
        Archivos.guardarIndice(Academia.SESIONES_IDX, indice, LARGO_CODIGO);

        aaaaa.cambiarSesiones(Academia.INSTRUCTORES_DAT, Academia.indiceInstructores, cedIns, 1);
        aaaaa.cambiarSesiones(Academia.APRENDICES_DAT, Academia.indiceAprendices, cedApr, 1);

        return "OK: Sesión " + codigo + " asignada (" + aprendiz[1] + " con " + instructor[1]
                + " el " + fecha + ").";
    }

    /** Solo se cancela si la fecha es futura: una sesión pasada ya se realizó. */
    public static String cancelar(String codigo) throws IOException {
        codigo = codigo == null ? "" : codigo.trim().toUpperCase();
        String[] s = buscar(codigo);
        if (s == null) {
            return "ERROR: No existe una sesión con ese código.";
        }
        if (s[6].compareTo(Archivos.hoy()) <= 0) {
            return "ERROR: No se puede cancelar: la sesión del " + s[6] + " ya se realizó.";
        }

        s[7] = "false";
        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "rw");
        archivo.seek(indice.get(codigo));
        escribir(archivo, s);
        archivo.close();

        indice.remove(codigo);
        Archivos.guardarIndice(Academia.SESIONES_IDX, indice, LARGO_CODIGO);

        aaaaa.cambiarSesiones(Academia.INSTRUCTORES_DAT, Academia.indiceInstructores, s[4], -1);
        aaaaa.cambiarSesiones(Academia.APRENDICES_DAT, Academia.indiceAprendices, s[1], -1);

        return "OK: Sesión cancelada.";
    }

    /** Si cedula viene vacía, devuelve todas las sesiones activas. */
    public static String listar(String cedula) throws IOException {
        File datos = new File(Academia.SESIONES_DAT);
        if (!datos.exists() || datos.length() == 0) {
            return "Todavía no hay sesiones registradas.";
        }
        cedula = cedula == null ? "" : cedula.trim();

        String texto = "CODIGO  FECHA        APRENDIZ                 ESPECIALIDAD  INSTRUCTOR\n";
        boolean hay = false;

        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "r");
        while (archivo.getFilePointer() < archivo.length()) {
            String[] s = leer(archivo);
            if (s[7].equals("true") && (cedula.equals("") || s[1].equals(cedula))) {
                texto = texto + Archivos.rellenar(s[0], 8) + Archivos.rellenar(s[6], 13)
                        + Archivos.rellenar(s[2], 25) + Archivos.rellenar(s[3], 14) + s[5] + "\n";
                hay = true;
            }
        }
        archivo.close();
        return hay ? texto : "No hay sesiones para mostrar.";
    }

    public static String instructoresDisponibles(String especialidad) throws IOException {
        File datos = new File(Academia.INSTRUCTORES_DAT);
        if (!datos.exists() || datos.length() == 0) {
            return "";
        }

        String texto = "";
        RandomAccessFile archivo = new RandomAccessFile(Academia.INSTRUCTORES_DAT, "r");
        while (archivo.getFilePointer() < archivo.length()) {
            String[] p = aaaaa.leer(archivo);
            if (p[5].equals("true") && p[2].equalsIgnoreCase(especialidad)
                    && Integer.parseInt(p[4]) < MAX_INSTRUCTOR) {
                texto = texto + p[0] + "  -  " + p[1] + "  (" + p[4] + "/" + MAX_INSTRUCTOR + ")\n";
            }
        }
        archivo.close();
        return texto;
    }

    public static int contarDelAprendiz(String cedula, String especialidad) throws IOException {
        File datos = new File(Academia.SESIONES_DAT);
        if (!datos.exists() || datos.length() == 0) {
            return 0;
        }

        int cuenta = 0;
        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "r");
        while (archivo.getFilePointer() < archivo.length()) {
            String[] s = leer(archivo);
            if (s[7].equals("true") && s[1].equals(cedula) && s[3].equalsIgnoreCase(especialidad)) {
                cuenta = cuenta + 1;
            }
        }
        archivo.close();
        return cuenta;
    }

    public static boolean hayRepetida(String cedApr, String cedIns, String fecha) throws IOException {
        File datos = new File(Academia.SESIONES_DAT);
        if (!datos.exists() || datos.length() == 0) {
            return false;
        }

        boolean repetida = false;
        RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "r");
        while (archivo.getFilePointer() < archivo.length()) {
            String[] s = leer(archivo);
            if (s[7].equals("true") && s[6].equals(fecha)
                    && (s[1].equals(cedApr) || s[4].equals(cedIns))) {
                repetida = true;
            }
        }
        archivo.close();
        return repetida;
    }

    public static String reporte() throws IOException {
        String texto = "REPORTE - " + Archivos.hoy() + "\n\nDISPONIBILIDAD DE INSTRUCTORES\n";

        File datosIns = new File(Academia.INSTRUCTORES_DAT);
        if (datosIns.exists() && datosIns.length() > 0) {
            RandomAccessFile archivo = new RandomAccessFile(Academia.INSTRUCTORES_DAT, "r");
            while (archivo.getFilePointer() < archivo.length()) {
                String[] p = aaaaa.leer(archivo);
                if (p[5].equals("true")) {
                    String estado = Integer.parseInt(p[4]) >= MAX_INSTRUCTOR ? "AGENDA LLENA" : "DISPONIBLE";
                    texto = texto + Archivos.rellenar(p[1], 25) + Archivos.rellenar(p[2], 14)
                            + p[4] + "/" + MAX_INSTRUCTOR + "  " + estado + "\n";
                }
            }
            archivo.close();
        }

        texto = texto + "\nSESIONES PROGRAMADAS\n";
        File datosSes = new File(Academia.SESIONES_DAT);
        if (datosSes.exists() && datosSes.length() > 0) {
            RandomAccessFile archivo = new RandomAccessFile(Academia.SESIONES_DAT, "r");
            while (archivo.getFilePointer() < archivo.length()) {
                String[] s = leer(archivo);
                if (s[7].equals("true")) {
                    texto = texto + Archivos.rellenar(s[0], 8) + Archivos.rellenar(s[6], 13)
                            + Archivos.rellenar(s[2], 25) + Archivos.rellenar(s[3], 14) + s[5] + "\n";
                }
            }
            archivo.close();
        }

        return texto;
    }
}
